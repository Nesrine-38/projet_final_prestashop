INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('1','ybcPaymentLogo','1','0','1','1','paymentlogos.png','','','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('2','displayTopColumn','1','1','0','1','banner-small-1.jpg','','','2');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('14','ybcCustom2','1','0','0','1','bg-tesimonial.png','','','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('21','ybcCustom5','1','0','1','1','','','','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('22','ybcCustom5','1','0','1','1','','','','2');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('23','ybcCustom5','1','0','1','1','','','','3');


