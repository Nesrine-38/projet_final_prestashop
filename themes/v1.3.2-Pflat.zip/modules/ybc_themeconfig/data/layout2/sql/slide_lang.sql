INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('5','_ID_LANG_','Welcome to our office store','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec <br />odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi.</p>','The best office supplies','Purchase now','#','732a9484e1f941ad57cd6f32d1e739d24ea4689f_slider.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('6','_ID_LANG_','office furniture and supplies','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec <br /> odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi.</p>','get ready for school','Purchase Now','#','1d8b623a52d51934c99bff4c0e34c8c6490a1c6c_slider2-2.jpg');


