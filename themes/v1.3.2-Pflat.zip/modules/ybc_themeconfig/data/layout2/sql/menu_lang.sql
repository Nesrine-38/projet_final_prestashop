INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('1','_ID_LANG_','Home');
INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('5','_ID_LANG_','Contact');
INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('8','_ID_LANG_','Blog');
INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('12','_ID_LANG_','Office supplies');
INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('13','_ID_LANG_','Accessories');
INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('18','_ID_LANG_','Office');


INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('4','_ID_LANG_','','');


INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('6','_ID_LANG_','Dolor sit amet','<ul><li><a href=\"#\">Sed do eiusmod</a></li>
<li><a href=\"#\">Excepteur sint</a></li>
<li><a href=\"#\">Duis aute irure</a></li>
<li><a href=\"#\">Ut enim ad </a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('7','_ID_LANG_','Accessories','<ul><li><a href=\"#\">Sed do eiusmod</a></li>
<li><a href=\"#\">Excepteur sint</a></li>
<li><a href=\"#\">Duis aute irure</a></li>
<li><a href=\"#\">Ut enim ad </a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('8','_ID_LANG_','Fashion','<ul><li><a href=\"#\">Sed do eiusmod</a></li>
<li><a href=\"#\">Excepteur sint</a></li>
<li><a href=\"#\">Duis aute irure</a></li>
<li><a href=\"#\">Ut enim ad </a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('9','_ID_LANG_','Duis aute irure','<ul><li><a href=\"#\">Sed do eiusmod</a></li>
<li><a href=\"#\">Excepteur sint</a></li>
<li><a href=\"#\">Duis aute irure</a></li>
<li><a href=\"#\">Ut enim ad </a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('10','_ID_LANG_','image','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('11','_ID_LANG_','image','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('12','_ID_LANG_','Contact link','<ul><li><a href=\"http://theme.yourbestcode.com/perfect/en/contact-us?YBC_TC_CONTACT_FORM_LAYOUT=layout1\">Contact page 1</a></li>
<li><a href=\"http://theme.yourbestcode.com/perfect/en/contact-us?YBC_TC_CONTACT_FORM_LAYOUT=layout2\">Contact page 2</a></li>
<li><a href=\"http://theme.yourbestcode.com/perfect/en/contact-us?YBC_TC_CONTACT_FORM_LAYOUT=layout3\">Contact page 3</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('13','_ID_LANG_','Cosmetics','<ul><li><a href=\"http://theme.yourbestcode.com/imake/en/14-lips\">Lips</a></li>
<li><a href=\"http://theme.yourbestcode.com/imake/en/15-skin-care\">Skin Care</a></li>
<li><a href=\"http://theme.yourbestcode.com/imake/en/18-brows\">Brows</a></li>
<li><a href=\"http://theme.yourbestcode.com/imake/en/12-cosmetics\">Cosmetics</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('14','_ID_LANG_','Lorem ipsum','<ul><li><a href=\"http://theme.yourbestcode.com/imake/en/18-brows\">Brows</a></li>
<li><a href=\"http://theme.yourbestcode.com/imake/en/14-lips\">Lips</a></li>
<li><a href=\"http://theme.yourbestcode.com/imake/en/12-cosmetics\">Cosmetics</a></li>
<li><a href=\"http://theme.yourbestcode.com/imake/en/15-skin-care\">Skin Care</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('15','_ID_LANG_','Lorem ipsum','<ul><li><a href=\"http://theme.yourbestcode.com/imake/en/12-cosmetics\">Cosmetics</a></li>
<li><a href=\"http://theme.yourbestcode.com/imake/en/15-skin-care\">Skin Care</a></li>
<li><a href=\"http://theme.yourbestcode.com/imake/en/18-brows\">Brows</a></li>
<li><a href=\"http://theme.yourbestcode.com/imake/en/14-lips\">Lips</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('16','_ID_LANG_','Categories','<ul><li><a href=\"http://theme.yourbestcode.com/imake/en/15-skin-care\">Skin Care</a></li>
<li><a href=\"http://theme.yourbestcode.com/imake/en/18-brows\">Brows</a></li>
<li><a href=\"http://theme.yourbestcode.com/imake/en/14-lips\">Lips</a></li>
<li><a href=\"http://theme.yourbestcode.com/imake/en/12-cosmetics\">Cosmetics</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('17','_ID_LANG_','image','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('18','_ID_LANG_','image','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('19','_ID_LANG_','Samsung','<ul><li><a href=\"http://theme.yourbestcode.com/imake/en/22-headphone\">Headphone</a></li>
<li><a href=\"http://theme.yourbestcode.com/imake/en/20-television\">Television</a></li>
<li><a href=\"http://theme.yourbestcode.com/imake/en/21-camera\">Camera</a></li>
<li><a href=\"http://theme.yourbestcode.com/imake/en/19-mobile-phone\">Mobile phone</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('20','_ID_LANG_','Sony','<ul><li><a href=\"http://theme.yourbestcode.com/imake/en/21-camera\">Camera</a></li>
<li><a href=\"http://theme.yourbestcode.com/imake/en/22-headphone\">Headphone</a></li>
<li><a href=\"http://theme.yourbestcode.com/imake/en/20-television\">Television</a></li>
<li><a href=\"http://theme.yourbestcode.com/imake/en/19-mobile-phone\">Mobile phone</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('21','_ID_LANG_','Microsoft','<ul><li><a href=\"http://theme.yourbestcode.com/imake/en/19-mobile-phone\">Mobile phone</a></li>
<li><a href=\"http://theme.yourbestcode.com/imake/en/21-camera\">Camera</a></li>
<li><a href=\"http://theme.yourbestcode.com/imake/en/22-headphone\">Headphone</a></li>
<li><a href=\"http://theme.yourbestcode.com/imake/en/20-television\">Television</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('22','_ID_LANG_','Asus','<ul><li><a href=\"http://theme.yourbestcode.com/imake/en/21-camera\">Camera</a></li>
<li><a href=\"http://theme.yourbestcode.com/imake/en/19-mobile-phone\">Mobile phone</a></li>
<li><a href=\"http://theme.yourbestcode.com/imake/en/20-television\">Television</a></li>
<li><a href=\"http://theme.yourbestcode.com/imake/en/22-headphone\">Headphone</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('23','_ID_LANG_','image','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('24','_ID_LANG_','image','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('25','_ID_LANG_','Main page','<ul><li><a href=\"http://theme.yourbestcode.com/perfect/blog\">Main page</a></li>
<li><a href=\"http://theme.yourbestcode.com/perfect/blog/post/1-sample-post1.html\">Post page</a></li>
<li><a href=\"http://theme.yourbestcode.com/perfect/blog/category/1-fashion.html\">Category page</a></li>
<li><a href=\"http://theme.yourbestcode.com/perfect/blog/author/1-dola-nguyen\">Author page</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('26','_ID_LANG_','homepage1','<div class=\"img_homepage\" style=\"background-image:url(&quot;http://theme.yourbestcode.com/perfect/img/cms/home-1.jpg&quot;);\"><a href=\"http://theme.yourbestcode.com/perfect/en/?YBC_TC_LAYOUT=LAYOUT1&amp;tc_init=1&amp;YBC_TC_SKIN=RED\">  </a></div>
<h4 class=\"title_menu_homepage\"><a href=\"http://theme.yourbestcode.com/perfect/en/?YBC_TC_LAYOUT=LAYOUT1&amp;tc_init=1&amp;YBC_TC_SKIN=RED\">Home page 1</a></h4>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('27','_ID_LANG_','Home page 2','<div class=\"img_homepage\" style=\"background-image:url(&quot;http://theme.yourbestcode.com/perfect/img/cms/home-2.jpg&quot;);\"><a href=\"http://theme.yourbestcode.com/perfect/en/?YBC_TC_LAYOUT=LAYOUT2&amp;tc_init=1&amp;YBC_TC_SKIN=GREEN\">  </a></div>
<h4 class=\"title_menu_homepage\"><a href=\"http://theme.yourbestcode.com/perfect/en/?YBC_TC_LAYOUT=LAYOUT2&amp;tc_init=1&amp;YBC_TC_SKIN=GREEN\">Home page 2</a></h4>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('28','_ID_LANG_','Home page 3','<div class=\"img_homepage\" style=\"background-image:url(&quot;http://theme.yourbestcode.com/perfect/img/cms/home-3.jpg&quot;);\"><a href=\"http://theme.yourbestcode.com/perfect/en/?YBC_TC_LAYOUT=LAYOUT3&amp;tc_init=1&amp;YBC_TC_SKIN=RED\">  </a></div>
<h4 class=\"title_menu_homepage\"><a href=\"http://theme.yourbestcode.com/perfect/en/?YBC_TC_LAYOUT=LAYOUT3&amp;tc_init=1&amp;YBC_TC_SKIN=RED\">Home page 3</a></h4>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('29','_ID_LANG_','Home page 4','<div class=\"img_homepage\" style=\"background-image:url(&quot;http://theme.yourbestcode.com/perfect/img/cms/home-4.jpg&quot;);\"><a href=\"http://theme.yourbestcode.com/perfect/en/?YBC_TC_LAYOUT=LAYOUT4&amp;tc_init=1&amp;YBC_TC_SKIN=LIGHT_BLUE\">  </a></div>
<h4 class=\"title_menu_homepage\"><a href=\"http://theme.yourbestcode.com/perfect/en/?YBC_TC_LAYOUT=LAYOUT4&amp;tc_init=1&amp;YBC_TC_SKIN=LIGHT_BLUE\">Home page 4</a></h4>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('31','_ID_LANG_','Dolor sit amet','<ul><li><a href=\"#\">Sed do eiusmod</a></li>
<li><a href=\"#\">Excepteur sint</a></li>
<li><a href=\"#\">Duis aute irure</a></li>
<li><a href=\"#\">Ut enim ad </a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('32','_ID_LANG_','Dolor sit amet','<ul><li><a href=\"#\">Sed do eiusmod</a></li>
<li><a href=\"#\">Excepteur sint</a></li>
<li><a href=\"#\">Duis aute irure</a></li>
<li><a href=\"#\">Ut enim ad </a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('33','_ID_LANG_','Dolor sit amet','<ul><li><a href=\"#\">Sed do eiusmod</a></li>
<li><a href=\"#\">Excepteur sint</a></li>
<li><a href=\"#\">Duis aute irure</a></li>
<li><a href=\"#\">Ut enim ad </a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('34','_ID_LANG_','Dolor sit amet','<ul><li><a href=\"#\">Sed do eiusmod</a></li>
<li><a href=\"#\">Excepteur sint</a></li>
<li><a href=\"#\">Duis aute irure</a></li>
<li><a href=\"#\">Ut enim ad </a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('35','_ID_LANG_','image','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('36','_ID_LANG_','image','');


