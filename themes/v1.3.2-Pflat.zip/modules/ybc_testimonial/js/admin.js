$(document).ready(function(){
    if($('.ybc_fancy').length > 0)
    {
        $('.ybc_fancy').fancybox();
    }
});