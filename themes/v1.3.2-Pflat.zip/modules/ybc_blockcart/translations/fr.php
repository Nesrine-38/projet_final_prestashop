<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockcart}prestashop>blockcart_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activé';
$_MODULE['<{blockcart}prestashop>blockcart_b9f5c797ebbf55adccdd8539a65a0241'] = 'Désactivé';
$_MODULE['<{blockcart}prestashop>blockcart_a87a2d4a45b5a7e682089167c1d5232a'] = 'Activer le cross-selling';
$_MODULE['<{blockcart}prestashop>blockcart_89e535251f4749df29ad3a288deaa017'] = 'Activer l\'affichage du cross-selling dans le panier.';
$_MODULE['<{blockcart}prestashop>blockcart_f2a6c498fb90ee345d997f888fce3b18'] = 'Supprimer';
$_MODULE['<{blockcart}prestashop>crossselling_4351cfebe4b61d8aa5efa1d020710005'] = 'Afficher';


return $_MODULE;
