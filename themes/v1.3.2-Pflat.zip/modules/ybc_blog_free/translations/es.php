<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ybc_blog_free}prestashop>blog_list_59526bf44608558c7a7331e99f4b8038'] = 'Últimas publicaciones';
$_MODULE['<{ybc_blog_free}prestashop>blog_list_53eef1dc1c84ebd17d645173b7b7655a'] = 'Buscar:';
$_MODULE['<{ybc_blog_free}prestashop>blog_list_222100df7fee41afa5d39aef8337a562'] = 'Autor:';
$_MODULE['<{ybc_blog_free}prestashop>blog_list_8413c683b4b27cc3f4dbd4c90329d8ba'] = 'Comentarios';
$_MODULE['<{ybc_blog_free}prestashop>blog_list_decbe415d8accca7c2c16d48a79ee934'] = 'Lee mas';
$_MODULE['<{ybc_blog_free}prestashop>blog_list_16_59526bf44608558c7a7331e99f4b8038'] = 'Últimas publicaciones';
$_MODULE['<{ybc_blog_free}prestashop>gallery_03904e973e81c46dfc62dcc40779d51e'] = 'Galería de imágenes';
$_MODULE['<{ybc_blog_free}prestashop>gallery_16_03904e973e81c46dfc62dcc40779d51e'] = 'Galería de imágenes';
$_MODULE['<{ybc_blog_free}prestashop>single_post_8413c683b4b27cc3f4dbd4c90329d8ba'] = 'Comentarios';
$_MODULE['<{ybc_blog_free}prestashop>single_post_f629bf1c1f0bbf252a04c92ec02cd8ce'] = 'Tema';
$_MODULE['<{ybc_blog_free}prestashop>single_post_b3af7359325b2925acbf98a7484158bc'] = 'Comentario';
$_MODULE['<{ybc_blog_free}prestashop>single_post_7a8dbd683001159655afc3f4935b3fd4'] = 'Enviar';
$_MODULE['<{ybc_blog_free}prestashop>single_post_16_8413c683b4b27cc3f4dbd4c90329d8ba'] = 'Comentarios';
$_MODULE['<{ybc_blog_free}prestashop>single_post_16_f629bf1c1f0bbf252a04c92ec02cd8ce'] = 'Tema';
$_MODULE['<{ybc_blog_free}prestashop>single_post_16_b3af7359325b2925acbf98a7484158bc'] = 'Comentario';
$_MODULE['<{ybc_blog_free}prestashop>single_post_16_394efb42d8bf427587bc4333d7f461f1'] = 'Artículos Relacionados';
$_MODULE['<{ybc_blog_free}prestashop>categories_block_3cfd94e5b1e020a2b88c15f49d57886e'] = 'Categorías de blogs';
$_MODULE['<{ybc_blog_free}prestashop>featured_posts_block_17fe63a5060231fe0c7e84a0528bc7fd'] = 'Publicaciones destacadas';
$_MODULE['<{ybc_blog_free}prestashop>gallery_block_03904e973e81c46dfc62dcc40779d51e'] = 'Galería de imágenes';
$_MODULE['<{ybc_blog_free}prestashop>latest_posts_block_59526bf44608558c7a7331e99f4b8038'] = 'Últimas publicaciones';
$_MODULE['<{ybc_blog_free}prestashop>popular_posts_block_0422ae5ca6429121fc69c4eb1c643b32'] = 'Entradas populares';
$_MODULE['<{ybc_blog_free}prestashop>search_block_13348442cc6a27032d2b4aa28b75a5d3'] = 'Buscar';
