<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ybc_blog_free}prestashop>search_block_496d09a4b58f276873f653cbd25f8ced'] = 'Blog Search';
