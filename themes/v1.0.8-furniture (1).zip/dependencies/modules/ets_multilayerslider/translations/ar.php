<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ets_multilayerslider}prestashop>ets_multilayerslider_f422de11b2c5ee2731049197f3f6282d'] = 'Multi-layer slider PRO';
